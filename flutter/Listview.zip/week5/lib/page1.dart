import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Page1 extends StatefulWidget {
  String title = '';
  Page1({super.key, required this.title});

  @override
  State<Page1> createState() => _Page1State();
}

class _Page1State extends State<Page1> {
  List<String> items = List.generate(10, (index) => "Text $index");
  List<String> item_sub = List.generate(10, (index) => "Subtitle $index");

  late int idx = 0;
  late final TextEditingController _controller = TextEditingController();
  late final TextEditingController _subtitleController =
      TextEditingController();

  // Method to show SnackBar messages
  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white)),
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12), // Rounded corners
        ),
        margin: const EdgeInsets.all(10),
        backgroundColor: Colors.pink[200],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Colors.pink[200],
        elevation: 4,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 16.0),
            const Text(
              'Kachakorn Kaewsuriya',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.pink,
              ),
            ),
            const SizedBox(height: 8.0),
            const Text(
              '6606021421349',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 16.0),
            SizedBox(
              height: 350,
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (BuildContext context, int index) {
                  return Dismissible(
                    key: UniqueKey(),
                    onDismissed: (direction) {
                      setState(() {
                        items.removeAt(index);
                        item_sub.removeAt(index); // Remove subtitle
                        showMessage('Removed item at index: $index');
                      });
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 10.0),
                      decoration: BoxDecoration(
                        color: idx == index ? Colors.blue[50] : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: const Offset(0, 3), // Shadow direction
                          ),
                        ],
                      ),
                      child: ListTile(
                        leading: const Icon(
                          Icons.stars_rounded,
                          color: Colors.pink,
                        ),
                        title: Text(
                          items[index],
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(item_sub[index]),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: () {
                                setState(() {
                                  _controller.text = items[index];
                                  _subtitleController.text = item_sub[
                                      index]; // Initialize subtitle controller
                                  showModalBottomSheet(
                                    context: context,
                                    builder: (context) {
                                      return Container(
                                        padding: const EdgeInsets.all(16.0),
                                        margin: const EdgeInsets.all(16.0),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          boxShadow: [
                                            BoxShadow(
                                              color:
                                                  Colors.grey.withOpacity(0.2),
                                              spreadRadius: 2,
                                              blurRadius: 5,
                                              offset: const Offset(0, 3),
                                            ),
                                          ],
                                        ),
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                IconButton(
                                                  onPressed: () {
                                                    Navigator.pop(context);
                                                  },
                                                  icon: const Icon(
                                                    Icons.close,
                                                    color: Colors.red,
                                                  ),
                                                ),
                                                const SizedBox(width: 8.0),
                                                IconButton(
                                                  onPressed: () {
                                                    setState(() {
                                                      items[index] =
                                                          _controller.text;
                                                      item_sub[index] =
                                                          _subtitleController
                                                              .text;
                                                      Navigator.pop(context);
                                                      showMessage(
                                                          'Item updated');
                                                    });
                                                  },
                                                  icon: const Icon(
                                                    Icons.check,
                                                    color: Colors.pink,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const Text(
                                              'Edit Item and Subtitle',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            TextField(
                                              controller: _controller,
                                              decoration: InputDecoration(
                                                filled: true,
                                                fillColor: Colors.grey[200],
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                ),
                                                labelText: 'Item Name',
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            TextField(
                                              controller: _subtitleController,
                                              decoration: InputDecoration(
                                                filled: true,
                                                fillColor: Colors.grey[200],
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                ),
                                                labelText: 'Subtitle',
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  );
                                });
                              },
                              icon: const Icon(Icons.edit, color: Colors.pink),
                            ),
                            IconButton(
                              onPressed: () {
                                setState(() {
                                  items.removeAt(index);
                                  item_sub
                                      .removeAt(index); // Also remove subtitle
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: const Text(
                                        'Remove Success',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      duration: const Duration(seconds: 2),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      margin: const EdgeInsets.all(10),
                                      backgroundColor: Colors.pink,
                                      behavior: SnackBarBehavior.floating,
                                    ),
                                  );
                                });
                              },
                              icon: const Icon(Icons.remove_circle_outline,
                                  color: Colors.red),
                            ),
                          ],
                        ),
                        onTap: () {
                          setState(() {
                            idx = index;
                          });
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      items.clear();
                      item_sub.clear(); // Clear subtitles too
                      showMessage('Generated new list');
                      items = List.generate(10, (index) => "Text $index");
                      item_sub =
                          List.generate(10, (index) => "Subtitle $index");
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pink,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Gen new list',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                const SizedBox(width: 8.0),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _controller.clear();
                      _subtitleController.clear();
                      showModalBottomSheet(
                        context: context,
                        builder: (context) {
                          return Container(
                            padding: const EdgeInsets.all(16.0),
                            margin: const EdgeInsets.all(16.0),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.2),
                                  spreadRadius: 2,
                                  blurRadius: 5,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    IconButton(
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                      icon: const Icon(
                                        Icons.close,
                                        color: Colors.red,
                                      ),
                                    ),
                                    const SizedBox(width: 8.0),
                                    IconButton(
                                      onPressed: () {
                                        setState(() {
                                          items.add(_controller.text);
                                          item_sub.add(_subtitleController
                                              .text); // Add subtitle too
                                          Navigator.pop(context);
                                          showMessage(
                                              "Added Item: ${_controller.text}");
                                        });
                                      },
                                      icon: const Icon(
                                        Icons.check,
                                        color: Colors.pink,
                                      ),
                                    ),
                                  ],
                                ),
                                const Text(
                                  'Add Item and Subtitle',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                      color: Colors.white),
                                ),
                                const SizedBox(height: 12),
                                TextField(
                                  controller: _controller,
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.grey[200],
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    labelText: 'Item Name',
                                  ),
                                ),
                                const SizedBox(height: 12),
                                TextField(
                                  controller: _subtitleController,
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.grey[200],
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    labelText: 'Subtitle',
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pink,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Add item to list',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
            const SizedBox(height: 16.0),
          ],
        ),
      ),
    );
  }
}
