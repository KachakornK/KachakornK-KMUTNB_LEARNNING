//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import local_auth_darwin

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FLALocalAuthPlugin.register(with: registry.registrar(forPlugin: "FLALocalAuthPlugin"))
}
