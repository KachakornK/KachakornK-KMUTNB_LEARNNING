import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:sensor/sensor.dart';

class MyBio extends StatefulWidget {
  const MyBio({super.key});

  @override
  State<MyBio> createState() => _MyBioState();
}

class _MyBioState extends State<MyBio> {
  late final LocalAuthentication auth;
  bool _supperState = false;

  @override
  void initState() {
    super.initState();
    auth = LocalAuthentication();
    auth.isDeviceSupported().then((bool isSupported) => setState(() {
          _supperState = isSupported;
        }));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Flutter Bio Authentication Demo"),
        backgroundColor: Colors.purpleAccent,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 50,
            child: Icon(Icons.people_alt, size: 50),
          ),
          if (!_supperState) const Text("อุปกรณ์ไม่รองรับการยืนยันตัวตน"),
          Center(
            child: ElevatedButton(
              onPressed: _authenticate,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.zero,
                shape: CircleBorder(),
              ),
              child: SizedBox(
                width: 80,
                height: 80,
                child: Center(
                  child: Icon(Icons.fingerprint, size: 65),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _authenticate() async {
    try {
      bool authenticate = await auth.authenticate(
        localizedReason: "กรุณายืนยันตัวตนเพื่อเข้าใช้งาน",
        options: const AuthenticationOptions(
          stickyAuth: false,
          biometricOnly: false,
        ),
      );

      if (authenticate) {
        if (!mounted) return;
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
            title: const Text("ยืนยันตัวตนสำเร็จ"),
            content: const Text("ท่านกำลังเข้าสู่หน้าหลัก"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const SensorScreen(
                              title: "Sensor Demo",
                            )),
                  );
                },
                child: const Text("ตกลง"),
              ),
            ],
          ),
        );
      } else {
        if (!mounted) return;
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text("การยืนยันตัวตนล้มเหลว"),
            content: const Text("กรุณาลองใหม่อีกครั้ง"),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("ตกลง"),
              ),
            ],
          ),
        );
      }
    } on PlatformMenu catch (e) {
      print(e);
    }
  }
}
