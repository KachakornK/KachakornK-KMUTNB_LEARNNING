import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sensor/bio.dart';
import 'package:sensors_plus/sensors_plus.dart';

class SensorScreen extends StatefulWidget {
  final String title;
  const SensorScreen({super.key, required this.title});

  @override
  State<SensorScreen> createState() => _SensorScreenState();
}

class _SensorScreenState extends State<SensorScreen> {
  AccelerometerEvent? _accelerometerEvent;
  late StreamSubscription<AccelerometerEvent> _accelerometerSubscription;
  GyroscopeEvent? _gyroscopeEvent;
  late StreamSubscription<GyroscopeEvent> _gyroscopeSubscription;

  @override
  void initState() {
    super.initState();

    _accelerometerSubscription = accelerometerEvents.listen(
      (event) {
        setState(() {
          _accelerometerEvent = event;
        });
      },
      onError: (error) {
        _showSensorError("Accelerometer");
      },
    );

    _gyroscopeSubscription = gyroscopeEvents.listen(
      (event) {
        setState(() {
          _gyroscopeEvent = event;
        });
      },
      onError: (error) {
        _showSensorError("Gyroscope");
      },
    );
  }

  void _showSensorError(String sensorType) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("$sensorType not found"),
          content: Text(
              "It seems that your device doesn't support the $sensorType sensor."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("OK"),
            ),
          ],
        ),
      );
    });
  }

  @override
  void dispose() {
    _accelerometerSubscription.cancel();
    _gyroscopeSubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "ค่าจาก Accelerometer และ Gyroscope",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            if (_accelerometerEvent != null && _gyroscopeEvent != null)
              Column(
                children: [
                  Text(
                    'Ax: ${_accelerometerEvent!.x.toStringAsFixed(2)}, '
                    'Gx: ${_gyroscopeEvent!.x.toStringAsFixed(2)}',
                  ),
                  Text(
                    'Ay: ${_accelerometerEvent!.y.toStringAsFixed(2)}, '
                    'Gy: ${_gyroscopeEvent!.y.toStringAsFixed(2)}',
                  ),
                  Text(
                    'Az: ${_accelerometerEvent!.z.toStringAsFixed(2)}, '
                    'Gz: ${_gyroscopeEvent!.z.toStringAsFixed(2)}',
                  ),
                ],
              )
            else
              const Text("Waiting for sensor data..."),
            const SizedBox(height: 20),
            TextButton(
              style: ButtonStyle(
                backgroundColor:
                    MaterialStateProperty.all<Color>(Colors.purpleAccent),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyBio()),
                );
              },
              child: const Text("กลับหน้าหลัก",
                  style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}
