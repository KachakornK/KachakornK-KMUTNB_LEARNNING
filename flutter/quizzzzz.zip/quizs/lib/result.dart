import 'package:flutter/material.dart';

class Result extends StatefulWidget {
  final int score;
  final int totalQuestions;
  final int correctAnswers;
  final int totalAttempts;
  final int highestScore;
  final int lowestScore;

  const Result({
    super.key,
    required this.score,
    required this.totalQuestions,
    required this.correctAnswers,
    required this.totalAttempts,
    required this.highestScore,
    required this.lowestScore,
  });

  @override
  State<Result> createState() => _ResultState();
}

class _ResultState extends State<Result> {
  double get percentage => (widget.correctAnswers / widget.totalQuestions) * 100;

  String get grade {
    if (percentage >= 90) {
      return 'A';
    } else if (percentage >= 80) {
      return 'B';
    } else if (percentage >= 70) {
      return 'C';
    } else if (percentage >= 60) {
      return 'D';
    } else {
      return 'F';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Quiz Result"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Your score is: ${widget.score}",
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 16),
            Text(
              "Correct Answers: ${widget.correctAnswers}",
              style: TextStyle(fontSize: 20),
            ),
            Text(
              "Incorrect Answers: ${widget.totalQuestions - widget.correctAnswers}",
              style: TextStyle(fontSize: 20),
            ),
            Text(
              "Percentage: ${percentage.toStringAsFixed(2)}%",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 16),
            Text(
              "Total Attempts: ${widget.totalAttempts}",
              style: TextStyle(fontSize: 20),
            ),
            Text(
              "Highest Score: ${widget.highestScore}",
              style: TextStyle(fontSize: 20),
            ),
            Text(
              "Lowest Score: ${widget.lowestScore}",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 16),
            Text(
              "Grade: $grade",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
