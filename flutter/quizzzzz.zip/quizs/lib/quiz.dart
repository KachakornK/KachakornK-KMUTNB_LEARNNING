import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:quiz/quizmodel.dart';
import 'package:quiz/result.dart';

class Quiz extends StatefulWidget {
  const Quiz({super.key});

  @override
  State<Quiz> createState() => _QuizState();
}

class _QuizState extends State<Quiz> {
  late List<Quizmodel> quiz = [];
  List<int> multichoice = [];
  final ScrollController _scrollController = ScrollController();
  int score = 0;
  int correctAnswers = 0;
  int totalAttempts = 0;
  int highestScore = 0;
  int lowestScore = 100;

  void finish() {
    setState(() {
      totalAttempts++;
      highestScore = score > highestScore ? score : highestScore;
      lowestScore = score < lowestScore ? score : lowestScore;
    });
  }

  bool isStarted = false;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      setState(() {
        text = "$multichoice";
      });
    });
  }

  List shuffle(List items) {
    var random = Random();
    for (var i = items.length - 1; i > 0; i--) {
      var n = random.nextInt(i + 1);
      var temp = items[i];
      items[i] = items[n];
      items[n] = temp;
    }
    return items;
  }

  void loadjson() async {
    final String response =
        await rootBundle.loadString("assets/json/data.json");
    final jsdata = quizModelFromJson(response);
    quiz = jsdata;
    shuffle(quiz);
    for (var q in quiz) {
      shuffle(q.choice);
    }
    quiz = quiz.sublist(0, 9);
    setState(() {
      multichoice = List.filled(quiz.length, 0);
      text = "$quiz $multichoice";
      isStarted = true;
    });
  }

  int calculateScore() {
    int score = 0;
    correctAnswers = 0;
    for (int i = 0; i < quiz.length; i++) {
      if (multichoice[i] == quiz[i].answerid) {
        score++;
        correctAnswers++;
      }
    }
    return score;
  }

  String text = "test";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Quiz Quiz Quiz"),
      ),
      body: Column(
        children: [
          quiz.isNotEmpty
              ? Expanded(
                  child: ListView.builder(
                      controller: _scrollController,
                      shrinkWrap: true,
                      itemCount: quiz.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            if (quiz[index].image != null)
                              Image.network(quiz[index].image!),
                            Text(
                              quiz[index].title,
                              style: TextStyle(fontSize: 36),
                            ),
                            ListView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: quiz[index].choice.length,
                                itemBuilder: (context, idx) {
                                  return ListTile(
                                    leading: Radio(
                                      value: quiz[index].choice[idx].id,
                                      groupValue: multichoice[index],
                                      onChanged: (int? value) {
                                        setState(() {
                                          multichoice[index] = value!;
                                        });
                                      },
                                    ),
                                    title: Text(quiz[index].choice[idx].title),
                                  );
                                })
                          ],
                        );
                      }))
              : Text(""),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              isStarted
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            score = calculateScore();
                            finish();
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Result(
                                  score: score,
                                  totalQuestions: quiz.length,
                                  correctAnswers: correctAnswers,
                                  totalAttempts: totalAttempts,
                                  highestScore: highestScore,
                                  lowestScore: lowestScore,
                                ),
                              ),
                            );
                          },
                          child: Text("Finish"),
                        ),
                        SizedBox(width: 10),
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              loadjson();
                            });
                          },
                          child: Text("Restart"),
                        ),
                      ],
                    )
                  : ElevatedButton(
                      onPressed: () {
                        loadjson();
                        setState(() {
                          isStarted = true;
                        });
                      },
                      child: Text("Start")),
            ],
          ),
        ],
      ),
    );
  }
}
