import 'dart:convert';

List<Quizmodel> quizModelFromJson(String str) {
  return List<Quizmodel>.from(
      json.decode(str).map((x) => Quizmodel.fromJson(x)));
}

String quizModelToJson(List<Quizmodel> data) {
  return json.encode(List<dynamic>.from(data.map((x) => x.toJson())));
}

class Choice {
  int id;
  String title;

  Choice({required this.id, required this.title});

  factory Choice.fromJson(Map<String, dynamic> json) {
    return Choice(id: json["id"], title: json["title"]);
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "title": title,
    };
  }
}

class Quizmodel {
  String title;
  List<Choice> choice;
  int answerid;
  String? image; 

  Quizmodel({
    required this.title,
    required this.choice,
    required this.answerid,
    this.image,
  });

  factory Quizmodel.fromJson(Map<String, dynamic> json) {
    return Quizmodel(
      title: json["title"],
      choice: List<Choice>.from(json["choice"].map((x) => Choice.fromJson(x))),
      answerid: json["answerid"],
      image: json["image"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "title": title,
      "choice": List<dynamic>.from(choice.map((x) => x.toJson())),
      "answerid": answerid
    };
  }
}
