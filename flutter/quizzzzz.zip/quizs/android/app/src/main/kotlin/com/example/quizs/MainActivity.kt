package com.example.quizs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
